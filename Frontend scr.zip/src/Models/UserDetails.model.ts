export class UserDetails{
    
    userId:number=0;
    role:string='';
    firstName:string='';
    lastName:string='';
    emailId:string='';
    mobileNumber:string='';
    addressInfo:string='';
    city:string='';
    state:string='';
    pincode:string='';
    password:string='';
    isLogin:boolean=false;
    createdDate:any;

}