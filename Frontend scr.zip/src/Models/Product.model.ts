export interface Product{
    productId:number;
    category:string;
    productName:string;
    price:number;
    description:string;
    productImage:string;
   
}