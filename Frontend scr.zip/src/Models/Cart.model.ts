export default interface Cart{
   
    cartId:number ;
    userId:number;
    productId:number;
    productImage:string;
    productName:string;
    quantity:number;
    price:number;
}