export interface Payment{
    transactionId:number;
    Fullname:string;
    transactionAmount:number;
    mode:string;
    cardnumber:number;
    cardcvv:number;

}