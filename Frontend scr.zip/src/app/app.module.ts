import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { CartComponent } from './cart/cart.component';
import { HomePageComponent } from './home-page/home-page.component';
import { LogInComponent } from './log-in/log-in.component';
import { OrderComponent } from './order/order.component';
import { PaymentComponent } from './payment/payment.component';
import { ProductComponent } from './product/product.component';
import { SellerPageComponent } from './seller-page/seller-page.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { UserPageComponent } from './user-page/user-page.component';
import { AdminAccountComponent } from './admin-page/MyAccount/admin-account/admin-account.component';
import { SellerProfileComponent } from './seller-page/Account/seller-profile/seller-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CartuserComponent } from './user-page/cartuser/cartuser/cartuser.component';
import { SearchComponent } from './user-page/search/search/search.component';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OrderstatusComponent } from './orderstatus/orderstatus.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminPageComponent,
    CartComponent,
    HomePageComponent,
    LogInComponent,
    OrderComponent,
    PaymentComponent,
    ProductComponent,
    SellerPageComponent,
    SignUpComponent,
    UserPageComponent,
    AdminAccountComponent,
    SellerProfileComponent,
    CartuserComponent,
    SearchComponent,
    OrderstatusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule,
    RouterModule,
    BrowserAnimationsModule,
    FormsModule,
    ToastrModule.forRoot({
      positionClass:'toast-top-right'
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
