import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cartuser',
  templateUrl: './cartuser.component.html',
  styleUrls: ['./cartuser.component.css']
})
export class CartuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
